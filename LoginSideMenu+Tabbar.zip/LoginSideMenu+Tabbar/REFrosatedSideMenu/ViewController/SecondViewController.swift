//
//  SecondViewController.swift
//  REFrosatedSideMenu
//
//  Created by Tejora on 09/10/18.
//  Copyright © 2018 Tejora. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func popUpbtn(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "ApproveRejectPopUp") as! ApproveRejectPopUp
        //vc.modalPresentationStyle = .fullScreen
        vc.modalPresentationStyle = .overCurrentContext
        self.navigationController?.present(vc, animated: true, completion: nil)
    }
    @IBAction func callNextcv(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "NextClass") as? NextClass
        
        if let aVc = vc {
            self.navigationController?.pushViewController(aVc, animated: true)
        }
    }
    @IBAction func showMenu(_ sender: Any) {
        view.endEditing(true)
        self.frostedViewController.view.endEditing(true)
        self.frostedViewController.presentMenuViewController()
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
