//
//  RootViewController.swift
//  REFrosatedSideMenu
//
//  Created by Tejora on 09/10/18.
//  Copyright © 2018 Tejora. All rights reserved.
//

import UIKit

class RootViewController: REFrostedViewController {

    override func awakeFromNib() {
        contentViewController = self.storyboard?.instantiateViewController(withIdentifier: "contentController")
        menuViewController = self.storyboard?.instantiateViewController(withIdentifier: "menuController")
    }

}
