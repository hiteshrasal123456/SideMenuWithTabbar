//
//  HomeViewController.swift
//  REFrosatedSideMenu
//
//  Created by Tejora on 09/10/18.
//  Copyright © 2018 Tejora. All rights reserved.
//

import UIKit

class HomeViewController: UIViewController {
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        DispatchQueue.main.async {
            let obj = self.storyboard?.instantiateViewController(withIdentifier: "BaseNaviVC") as! BaseNaviVC
            obj.navigationController?.isNavigationBarHidden = true
        }
        
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func btnNextVC(_ sender: Any) {
        let vcObj = self.storyboard?.instantiateViewController(withIdentifier: "NextClass") as! NextClass
        
        //self.show(vcObj, sender: self)
        self.navigationController?.pushViewController(vcObj, animated: true)
    }
    
    @IBAction func showMenu(_ sender: Any) {
        view.endEditing(true)
        self.frostedViewController.view.endEditing(true)
        self.frostedViewController.presentMenuViewController()
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
