//
//  PRSApprovalRejectPopup.swift
//  REFrosatedSideMenu
//
//  Created by Hitesh Rasal on 16/10/20.
//  Copyright © 2020 Tejora. All rights reserved.
//

import UIKit

class PRSApprovalRejectPopup: UIViewController {

    @IBOutlet weak var btnSubmit: UIButton!
    @IBOutlet weak var mainContainerVw: UIView!
    override func viewDidLoad() {
        super.viewDidLoad()
        mainContainerVw.setCornerRadius(radius: 12)
        btnSubmit.setCornerRadius(radius: 8)
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    @IBAction func btnSubmit(_ sender: Any) {
    }
    @IBAction func btnClose(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }

}
