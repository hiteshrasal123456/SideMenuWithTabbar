//
//  SplashVC.swift
//  REFrosatedSideMenu
//
//  Created by Tejora on 09/10/18.
//  Copyright © 2018 Tejora. All rights reserved.
//

import UIKit


class SplashVC: UIViewController,REFrostedViewControllerDelegate {
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        self.navigationController?.isNavigationBarHidden = true
        if UserDefaults.standard.bool(forKey: "loggedIn") {
            userLoggedIn()
        } else {
            userNoLogin()
        }
        
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        
        

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func userNoLogin() {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "LoginVc") as? LoginVc
        if let aVc = vc {
            self.navigationController?.pushViewController(aVc, animated: true)
        }
    }
    func userLoggedIn() {
        let navigationController = self.storyboard?.instantiateViewController(withIdentifier: "contentController") as? NavigationController
        let menuController = self.storyboard?.instantiateViewController(withIdentifier: "menuController") as? MenuViewController
        
        let frostedViewController = REFrostedViewController(contentViewController: navigationController, menuViewController: menuController)
        frostedViewController?.direction = .left
        frostedViewController?.liveBlurBackgroundStyle = .light
        frostedViewController?.liveBlur = true
        frostedViewController?.delegate = self
        
        self.navigationController?.pushViewController(frostedViewController!, animated: true)
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
