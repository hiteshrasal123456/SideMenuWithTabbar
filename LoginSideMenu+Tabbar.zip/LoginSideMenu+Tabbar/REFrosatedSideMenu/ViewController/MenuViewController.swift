//
//  MenuViewController.swift
//  REFrosatedSideMenu
//
//  Created by Tejora on 09/10/18.
//  Copyright © 2018 Tejora. All rights reserved.
//

import UIKit

class MenuViewController: UIViewController{
    var menuListArray : [String]!
    @IBOutlet weak var tblView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        self.menuListArray = ["One","Two","Three"]
        self.tblView.delegate = self
        self.tblView.dataSource = self
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}

extension MenuViewController: UITableViewDelegate,UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.menuListArray.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: .default, reuseIdentifier: "cell")
        cell.textLabel?.text = self.menuListArray[indexPath.row] as! String
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let navigationController = self.storyboard?.instantiateViewController(withIdentifier: "contentController") as? NavigationController
        if indexPath.row == 0 {
            let homeViewController = self.storyboard?.instantiateViewController(withIdentifier: "TabBarVc") as? TabBarVc
            navigationController?.viewControllers = [homeViewController] as! [UIViewController]
        }else if indexPath.row == 1{
            let secondViewController = self.storyboard?.instantiateViewController(withIdentifier: "secondController") as? SecondViewController
            navigationController?.viewControllers = [secondViewController] as! [UIViewController]
        }else if indexPath.row == 2 {
            let secondViewController = self.storyboard?.instantiateViewController(withIdentifier: "secondController") as? SecondViewController
            navigationController?.viewControllers = [secondViewController] as! [UIViewController]
        }
        self.frostedViewController.contentViewController = navigationController
        self.frostedViewController.hideMenuViewController()
    }
}
