//
//  LoginVc.swift
//  REFrosatedSideMenu
//
//  Created by Tejora on 09/10/18.
//  Copyright © 2018 Tejora. All rights reserved.
//

import UIKit

class LoginVc: UIViewController,REFrostedViewControllerDelegate {
    
    
    @IBOutlet weak var loginContainer: UIView!
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        self.navigationController?.isNavigationBarHidden = true
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        loginContainer.setCornerRadius(radius: 10)
        loginContainer.dropShadow()
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    @IBAction func LoginAction(_ sender: Any) {
      //  let TabBarVc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "TabBarVc") as! TabBarVc
     //   TabBarVc.navigationController?.isNavigationBarHidden = true
        let navigationController = self.storyboard?.instantiateViewController(withIdentifier: "contentController") as? NavigationController
        let menuController = self.storyboard?.instantiateViewController(withIdentifier: "menuController") as? MenuViewController
        
        let frostedViewController = REFrostedViewController(contentViewController: navigationController, menuViewController: menuController)
        frostedViewController?.direction = .left
        frostedViewController?.liveBlurBackgroundStyle = .light
        frostedViewController?.liveBlur = true
        frostedViewController?.delegate = self
        UserDefaults.standard.set(true, forKey: "loggedIn")
        self.navigationController?.pushViewController(frostedViewController!, animated: true)
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

    
    
    //MARK: REFrosated delegate methods
    func frostedViewController(_ frostedViewController: REFrostedViewController!, didRecognizePanGesture recognizer: UIPanGestureRecognizer!) {
        
    }
    
    func frostedViewController(_ frostedViewController: REFrostedViewController!, willShowMenuViewController menuViewController: UIViewController!) {
        
    }
    
    func frostedViewController(_ frostedViewController: REFrostedViewController!, didShowMenuViewController menuViewController: UIViewController!) {
        
    }
    func frostedViewController(_ frostedViewController: REFrostedViewController!, willHideMenuViewController menuViewController: UIViewController!) {
        
    }
    func frostedViewController(_ frostedViewController: REFrostedViewController!, didHideMenuViewController menuViewController: UIViewController!) {
        
    }
}

extension UIView {
    func setCornerRadius(radius: CGFloat) {
        layer.cornerRadius = radius
    }
    /*
    Method Name   : dropShadow
    Functionality : DROP THE SHADOW ON VIEW EDGES
    */
    func dropShadow(scale: Bool = true) {
        layer.masksToBounds = false
        layer.shadowColor = UIColor.black.cgColor
        layer.shadowOpacity = 0.5
        layer.shadowOffset = .zero
        layer.shadowRadius = 10
        layer.shouldRasterize = true
        layer.rasterizationScale = scale ? UIScreen.main.scale : 1
    }
}
